import React from 'react';
import { LicenseStatus } from '../types';

interface StatusBadgeProps {
  status: LicenseStatus;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => {
  const styles = {
    Active: "bg-[#E8F5E9] text-[#2E7D32] border border-[#E8F5E9]",
    Expiring: "bg-[#FFF8E1] text-[#F57C00] border border-[#FFF8E1]",
    Expired: "bg-[#FFEBEE] text-[#C62828] border border-[#FFEBEE]",
  };

  return (
    <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wide ${styles[status]}`}>
      {status}
    </span>
  );
};